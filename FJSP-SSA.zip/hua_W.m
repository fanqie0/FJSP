w_min = 1;
w_max = 3;
f = unifrnd(1,10,1,100);
f = sort(f);
f_worst = max(f);
f_best = min(f);
for i = 1:length(f)
    w(i) = w_min + (w_max-w_min)*(sin(((f(i)-f_best)/(f_worst-f_best)+1)*pi/2+pi)+1);
end
figure(1)
plot(f,w);