function archive = cal_cd(archive)%计算拥挤度
global total_op_num
for j = 1 : object_num %
    [~,index] = sort(archive(:,total_op_num+j));%按第j个目标函数值进行排序
    archive = archive(index,:);
    f_max = archive(end,total_op_num+j);%第j个目标函数值最大的个体的值
    f_min = archive(1, total_op_num+j);
    archive(end,total_op_num+object_num+j)=Inf;%把第j个目标函数值最大的个体拥挤都设为Inf
    archive(1,total_op_num+object_num+j)=Inf;
    for k = 2 : size(archive,1) - 1
        next_obj = archive(k+1,total_op_num+object_num+j);
        previous_obj = archive(k-1,total_op_num+object_num+j);
        if (f_max - f_min == 0)
            archive(k,total_op_num+object_num+j) = Inf;
        else
            archive(k,total_op_num+object_num+j) = ...
                (next_obj - previous_obj)/(f_max - f_min);%算了每个目标函数下个体的拥挤度
        end
    end
end
archive(:,total_op_num+object_num+1)...%求总的拥挤度
    = sum(archive(:,total_op_num+object_num+1:total_op_num+object_num+object_num));
archive(:,total_op_num+object_num+1+1:end) = [];%把多于的数据给删除