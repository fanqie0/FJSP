%局部搜索
function pop_ls = local_search(pop,mac_time)
[pop_size,total_op_num] = size(pop);
for i = 1:pop_size
    pop_temp = pop(i,:);
    for j = 1:total_op_num
        %找到j对应的工序是pop_temp(j)的第几个工序
        op_index = find(find(pop_temp(1:total_op_num) == pop_temp(j)) == j);
        time = mac_time{pop_temp(j)}{op_index};%对应加工机器
        index = find(time == min(time));%找到加工时间最短的机器
        pop_temp(total_op_num+j) = index(1);%选择加工时间最短的机器(选择序号，不选机器编号)
    end
    pop_ls(i,:) = pop_temp;
end
        


