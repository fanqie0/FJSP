function pop_rs = rand_search(pop,op_mac)
[pop_size,total_op_num] = size(pop);
for i = 1:pop_size
    pop_temp = pop(i,:);
    for j = 1:total_op_num
        %找到j对应的工序是pop_temp(j)的第几个工序
        op_index = find(find(pop_temp(1:total_op_num) == pop_temp(j)) == j);
        machine = op_mac{pop_temp(j)}{op_index};%对应加工机器集合
        index = randperm(length(machine),1);%随机选择一个机器
        pop_temp(total_op_num+j) = index;%选择加工时间最短的机器(选择序号，不选机器编号)
    end
    pop_rs(i,:) = pop_temp;
end
        


