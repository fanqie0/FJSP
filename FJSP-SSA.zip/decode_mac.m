%生成机器编码
function pop_new = decode_mac(pop,op_mac,mac_time,mac_num,process_power)
glo_pro = 0.3;
loc_pro = 0.2;
cor_pro = 0.4;
rand_pro = 0.1;
[pop_size,~] = size(pop);
gs = pop_size*glo_pro;%全局搜索个体数
ls = pop_size*loc_pro;%局部搜索个体数
cs = pop_size*cor_pro;%按碳排放量搜索个数
pop_gs = global_search(pop(1:gs,:),op_mac,mac_time,mac_num);
pop_ls = local_search(pop(gs+1:gs+ls,:),mac_time);
pop_cs = carban_search(pop(gs+ls+1:gs+ls+cs,:),op_mac,mac_time,mac_num,process_power);
pop_rs = rand_search(pop(gs+ls+cs+1:end,:),op_mac);
pop_new = [pop_gs;pop_ls;pop_cs;pop_rs];