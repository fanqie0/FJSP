function [fit,record_pval,make_co_sum] = fitness_test(pop)
global job_num;
global mac_num mac_time idle_power process_power;
global total_op_num op_mac;

price = 0.729592;%电价
c_rate = 0.7242;%电网碳排放因子
for i = 1:size(pop,1)
    pop_new = pop(i,:);
    machine_time_end = zeros(1,mac_num); %记录机器加工结束时间
    job_time_end = zeros(1,job_num);  %记录工件加工结束时间
    machine_time = zeros(1,mac_num); %记录机器实际加工时间
    pval = zeros(2,total_op_num); %记录各工序加工开始和结束
    all_mac_num = [];%记录一个调度解对应的加工机器编号（不是序号）
    for j = 1:total_op_num
        op_index = find(find(pop_new == pop_new(j)) == j);  %找到pop_new(j)是pop_new(i)的第几个工序
        mac_index = op_mac{pop_new(j)}{op_index}(pop_new(total_op_num+j));
        all_mac_num = [all_mac_num,mac_index];
        %找到工件pop_new(i)的第op_index个工序对应机器编码pop_new(total_op_num+j)对应的机器编号mac_index
        %pop_new(total_op_num+j)是工件pop_new(j)的第op_index的工序加工机器集合中的第pop_new(total_op_num+j)个机器
        % 机器时间大于工件时间，也就是说工件等待机器
        %carban(j) = mac_time{pop_new(j)}{op_index}(mac_index)*process_power{pop_new(j)}{op_index}(mac_index);
        temp1 = mac_time{pop_new(j)}{op_index}(pop_new(j+total_op_num));
        temp2 = process_power{pop_new(j)}{op_index}(pop_new(j+total_op_num));
        carban(j) = temp1*temp2;
        if machine_time_end(mac_index)>=job_time_end(pop_new(j))
            pval(1,j) = machine_time_end(mac_index);
            temp_position = find(all_mac_num == mac_index);
            if length(temp_position) == 1 %机器刚开始加工
                machine_time_end(mac_index) ...
                    =  mac_time{pop_new(j)}{op_index}(pop_new(total_op_num+j));
                %= machine_time_end(mac_index)+ mac_time{pop_new(j)}{op_index}(pop_new(total_op_num+j));
            else
                machine_time_end(mac_index) ...
                    = machine_time_end(mac_index)+ mac_time{pop_new(j)}{op_index}(pop_new(total_op_num+j));
            end
            %mac_time{pop_new(j)}{op_index}(pop_new(total_op_num+j))是对应加工时间
            job_time_end(pop_new(j)) = machine_time_end(mac_index);
            pval(2,j) = machine_time_end(mac_index);

            % 机器时间小于工件时间，也就是机器等工件
        else
            pval(1,j)=job_time_end(pop_new(j));
            job_time_end(pop_new(j))...
                =job_time_end(pop_new(j))+mac_time{pop_new(j)}{op_index}(pop_new(total_op_num+j));
            machine_time_end(mac_index)=job_time_end(pop_new(j));
            pval(2,j)=job_time_end(pop_new(j));
        end
        machine_time(mac_index)=machine_time(mac_index)+mac_time{pop_new(j)}{op_index}(pop_new(total_op_num+j));
    end
    for k = 1:mac_num
        temp = find(all_mac_num == k);
        if ~isempty(temp) %如果temp非空
            last_mac(k) = temp(end);%找第k个机器的最后一个位置
            last_mac_time(k) = pval(2,last_mac(k));%找到第k个机器的最后完工时间
            idle_mac_time(k) = last_mac_time(k)-machine_time(k);%第k个机器的空闲时间
        else
            idle_mac_time(k) = 0;%如果没有用到第k个机器，那么将其空闲时间设为0
        end
    end
    idle_make_co = idle_power*idle_mac_time'*c_rate;%空闲碳排放量
    process_make_co = sum(carban)*c_rate;


    make_co_sum(i) = process_make_co+idle_make_co;%一个调度解的碳排放量
    fit(i) = max(max(pval));%一个调度解的最小加工时间
    record_pval(i,1:total_op_num) = pval(1,:);
    record_pval(i,total_op_num+1:total_op_num*2) = pval(2,:);

end


