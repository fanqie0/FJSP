%全局搜索
function pop_cs = carban_search_test(pop,op_mac,mac_num,carbon_emission)
car_temp = [138 	86 	24 	-1 	75 	-1 
9 	-1 	-1 	78 	-1 	53 
68 	52 	-1 	-1 	72 	-1 
12 	-1 	146 	-1 	-1 	55 
59 	24 	61 	48 	-1 	55 
-1 	43 	138 	-1 	-1 	-1 
95 	65 	-1 	-1 	-1 	-1 
-1 	-1 	162 	122 	-1 	198 
116 	-1 	71 	78 	-1 	-1 
86 	51 	-1 	-1 	43 	-1 
139 	8 	-1 	9 	57 	64 
-1 	-1 	313 	156 	15 	-1 
1 	-1 	167 	71 	15 	-1 
115 	54 	-1 	-1 	51 	122 
-1 	-1 	317 	162 	-1 	218 
135 	-1 	12 	72 	68 	-1 
68 	4 	-1 	66 	-1 	66 
99 	62 	-1 	18 	-1 	71 
-1 	-1 	13 	-1 	46 	77 
-1 	-1 	129 	-1 	43 	75 
15 	69 	-1 	-1 	6 	11 
-1 	8 	-1 	187 	83 	-1 
-1 	68 	-1 	-1 	-1 	85 
-1 	-1 	162 	143 	-1 	-1 
125 	88 	-1 	8 	9 	92 
83 	47 	83 	-1 	-1 	-1 
135 	88 	114 	-1 	-1 	-1 
-1 	-1 	-1 	96 	85 	112 
-1 	-1 	-1 	96 	-1 	132 
126 	-1 	155 	67 	77 	82 
];
price = 0.729592;%电价
c_rate = 0.7242;%电网碳排放因子

[pop_size,total_op_num] = size(pop);
for i = 1:pop_size
    pop_temp = pop(i,:);
    mac_car_total = zeros(1,mac_num);%把机器的碳排放量设为0
    for j = 1:total_op_num
        %找到j对应的工序是pop_temp(j)的第几个工序
        op_index = find(find(pop_temp(1:total_op_num) == pop_temp(j)) == j);
        machine = op_mac{pop_temp(j)}{op_index};%对应加工机器集合
        carbon = carbon_emission{pop_temp(j)}{op_index};%对应加工机器的碳排放量
        temp_carbon = zeros(1,mac_num);
        for k = 1:length(machine)
            temp_carbon(machine(k)) = mac_car_total(machine(k))+carbon(k);
        end
        index0 = find(temp_carbon ~= 0);%找总碳排放量不为零的机器的索引
        index1 = temp_carbon(index0);%对应总碳排放量
        index2 = find(index1 == min(index1));%找碳排放量最小的机器在index1中的位置
        mac_select = index0(index2(1));%选总碳排放量最小的第一个机器（可能有多个）
        pop_temp(total_op_num+j) = index2(1);%编码用的mac_select的在machine的序号
        mac_car_total(mac_select) = temp_carbon(mac_select);
    end
    pop_cs(i,:)=pop_temp;
end








