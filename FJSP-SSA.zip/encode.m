function pop_new = encode(pop,total_op_num,op_mac,mac_num)
pop = pop_new_T;
run read_data.m
for i = 1:size(pop,1)
    for j = 1:size(pop,2)/2
        ni = pop(i,total_op_num+j);
        temp_index = find(pop(i,1:total_op_num) == pop(i,j));
        op_index = find(temp_index == j); %j是第j个工件的第op_index个工序
        mac_number = size(op_mac{pop(i,j)}{op_index},2); %可选加工机器数
        if mac_number ~= 1
           pop_new(i,j) = 2*mac_num*(ni-1)/(mac_number-1)-mac_num; %调度解转化为个体位置
        else
           pop_new(i,j) = unifrnd(-mac_num,mac_num,1);
        end
    end
end

