function HV_value = HV(P)
%P是某次运行得到的非支配解，R是参考向量(列向量)，R被所有P支配
R = [max(P(:,1)),max(P(:,2))];
P = [P;R];
P = sortrows(P,1,'descend');%降序排列

for i = 1:size(P,1)-1
    area(i) = abs((P(i,2)-P(i+1,2)))*abs((P(i,1)-P(i+1,1)));
end

HV_value = sum(area);
end