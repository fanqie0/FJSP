clear
clc
global job_num job_rank 
global mac_num mac_time idle_power process_power start_time
global total_op_num op_mac 

pop = [-7.97376380284782	10	-2.28918526053620	3.25984261611979	-8.98979504535081	10	-4.43776890569262	6.14639311285117	-10	4.28761902238046	-6.66460781189823	8.31364505247381	-2.33209961307856	2.17546020030918	-6.11548520227898	8.70011055650187	3.61380339070401	-10	-8.74753880068658	10	0.169006890089834	-2.48827490503160	9.16419620383141	-0.205519590433834	5.64214783623922	-10	-9.31054094472131	6.19844623458244	-10	-10	-6.32898717323759	10	7.31812739720808	-6.31788305341243	8.86290928934628	4.53568127635612	-10	-10	-9.59818849065925	7.51805197828185	-5.99429853975867	10	10	0.744511742665303	-5.50356466568860	10	10	9.36785807753381	1.43640350139218	-4.59536592319131	10	10	5.93361218364351	-10	-9.87310206508320	5.38008205546652	6	6	6	6	-6	6	1.99305095849637	1.79575178544899	-4.55884837455939	6	-3.32780927087761	5.74563080808986	-6	-6	6	0.443922340329411	-6	-6	-6	6	-6	6	-6	6	6	-1.01233622859044	-6	6	-6	6	6	-5.53563820156701	-0.908656801465757	-6	0.548873306123830	6	6	6	-6	-1.29966388614832	-6	-6	6	6	6	-6	6	6	6	-6	6	0.320476897240943	0.244351533854462	6];
run read_data.m
%function pop_new = mutation(pop,pop_size,Pm)
pop_size = 200;
Pm = 2;
%输入的pop是个体位置
% 变邻域则是对工序编码进行交叉互换
%global total_op_num job_num mac_num op_mac

pop_decode = position_scheduling(pop);
pop_new = [];
pop_new_decode = [];
%% 工序变异（交换位置）
for i = 1:size(pop,1)
    if rand<Pm
        pop1 = pop(i,:);%原个体
        pop2 = pop(i,:);%交换过的个体
        pop1_decode = pop_decode(i,:);
        %index = sort(randperm(total_op_num,2));%选取两个点儿
        index = [37,54];
        %找index(1)对应工件的工序
        op_index1_pop1 = find(find(pop1_decode(1:total_op_num) == pop1_decode(index(1))) == index(1));
        %找index(2)对应工件的工序
        op_index2_pop1 = find(find(pop1_decode(1:total_op_num) == pop1_decode(index(2))) == index(2));
        %交换工序
        pop2(index(1)) = pop1(index(2));
        pop2(index(2)) = pop1(index(1));
        pop2_decode = position_scheduling(pop2);%解码
        %交换后个体pop2在index(2)位置上的工件工序
        op_index1_pop2 = find(pop2_decode(1:total_op_num) == pop2_decode(index(2)));
        op_index1_pop2 = find(op_index1_pop2 == index(2));

        %交换后个体pop2在index(1)位置上的工件工序
        op_index2_pop2 = find(pop2_decode(1:total_op_num) == pop2_decode(index(1)));
        op_index2_pop2 = find(op_index2_pop2 == index(1));

        %找原个体中op_index1_pop2和op_index2_pop2的位置
        %找到pop1中index(1)对应工件的所有工序在pop1中的位置
        op_index3_pop1 = find(pop1_decode(1:total_op_num) == pop1_decode(index(1)));
        %找到原个体pop1中index(1)对应工件的第op_index1_pop2个工序所在位置
        op_index3_pop1 = op_index3_pop1(op_index1_pop2);
        %找到pop1中index(2)对应工件的所有工序在pop1中的位置
        op_index4_pop1 = find(pop1_decode(1:total_op_num) == pop1_decode(index(2)));
        %找到原个体pop1中index(1)对应工件的第op_index2_pop2个工序所在位置
        op_index4_pop1 = op_index4_pop1(op_index2_pop2);

        %找交换后个体pop2中op_index1_pop1和op_index2_pop1的位置
        %找到pop2中index(2)对应工件的所有工序在pop2中的位置
        op_index3_pop2 = find(pop2_decode(1:total_op_num) == pop2_decode(index(2)));
        %找到原个体pop1中index(2)对应工件的第op_index1_pop2个工序所在位置
        op_index3_pop2 = op_index3_pop2(op_index1_pop1);
        %找到pop2中index(1)对应工件的所有工序在pop2中的位置
        op_index4_pop2 = find(pop2_decode(1:total_op_num) == pop2_decode(index(1)));
        %找到原个体pop1中index(1)对应工件的第op_index1_pop2个工序所在位置
        op_index4_pop2 = op_index4_pop2(op_index2_pop1);
        pop2(total_op_num+index(2)) = pop1(total_op_num+op_index3_pop1);
        pop2(total_op_num+index(1)) = pop1(total_op_num+op_index4_pop1);
        pop2(total_op_num+op_index3_pop2) = pop1(total_op_num+index(1));
        pop2(total_op_num+op_index4_pop2) = pop1(total_op_num + index(2));
        pop_new = [pop_new;pop2];
        pop_new_decode = [pop_new_decode;pop2_decode];
    end
end
%% 机器变异,随机选中两个变异点儿，然后更换机器
for i = 1:size(pop_new,1)
    if rand<Pm
        index_mac = randperm(total_op_num,2);
        for j = 1:length(index_mac)
            op_index = find(find(pop_new_decode(i,1:total_op_num) == pop_new_decode(i,index_mac(j))) == index_mac(j));
            tol_mac =1: length(op_mac{pop_new_decode(i,index_mac(j))}{op_index});
            mac_tol = length(tol_mac);
            if length(tol_mac) ~= 1 %判断可加工机器数是否大于1台
                tol_mac = setdiff(tol_mac,pop_new_decode(i,total_op_num+index_mac(j)));
                temp_index = randperm(length(tol_mac),1);
                mac_sel = tol_mac(temp_index);%这里也是序号，不是编号
                mac_pos = 2*mac_num*(mac_sel-1)/(mac_tol-1)-mac_num;%调度解转换为个体位置公式
                pop_new(i,total_op_num+index_mac(j)) = mac_pos;
            end
        end
    end
end


pop_new = [pop;pop_new];
%pop_new_decode = [pop_decode;pop_new_decode];
pop_new = unique(pop_new,'rows','stable');
pop_new_decode = position_scheduling(pop_new);
[fit,~] = fitness(pop_new_decode);
[Fit,index] = sort(fit);
if size(pop_new,1)< pop_size
    lack_num = pop_size-size(pop_new,1);%缺少的个体
    for j = 1:lack_num
        lack_pop(j,1:total_op_num) = unifrnd(-job_num,job_num);
        lack_pop(j,total_op_num+1:total_op_num*2) = unifrnd(-mac_num,mac_num);
    end
    pop_new = [pop_new(index,:);lack_pop];%可能除去重复值之后，个体数少于pop_size了
else
    pop_new = pop_new(index(1:pop_size),:);
end

%}