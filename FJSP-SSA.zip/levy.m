function levy = levy(~)
% Mantegna方法模拟萊维飞行
beta = 1.5;
sigma_u = (gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
%gamma(x)是计算x的伽马函数值
sigma_v = 1;
u = normrnd(0,sigma_u);% normrnd(mu,sigma)返回均值为mu,标准差为sigma的正态分布随机数
v = normrnd(0,sigma_v);
s = u/(abs(v))^(1/beta);
levy = s;
end