%这个是得到个体位置的排名
function B = sort_index(x)
[~,A] = sort(x); %X是列向量
B = zeros(size(A));
B(A) = (1:length(A))';