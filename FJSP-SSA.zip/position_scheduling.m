%个体位置转换为调度解
function pop_new = position_scheduling(pop)
global  job_rank mac_num
global total_op_num op_mac
[pop_size,~] = size(pop);
%生成随机数
for i = 1 : pop_size
    index = sort_index(pop(i,1:total_op_num));
    pop_new(i,1:total_op_num) = job_rank(index); %生成工序编码
    pop_new(i,total_op_num+1:total_op_num*2) = 0; %给机器编码赋值空间
    for j = 1:total_op_num
        op_index = find(find(pop_new(i,1:total_op_num) == pop_new(i,j)) == j);
        mac_number = size(op_mac{pop_new(i,j)}{op_index},2);
        pop_new(i,total_op_num+j) = round(1/(mac_num*2)*(pop(i,total_op_num+j)+mac_num)*(mac_number-1)+1);
    end
end


