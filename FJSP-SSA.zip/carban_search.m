%全局搜索
function pop_cs = carban_search(pop,op_mac,mac_time,mac_num,process_power)

price = 0.729592;%电价
c_rate = 0.7242;%电网碳排放因子
carbon_emission = cell(1,length(mac_time));
%先计算工序对应加工机器的碳排放量
for i = 1:length(mac_time)
    for j = 1:length(mac_time{i})
        for k = 1:length(mac_time{i}{j})
            %carbon_emission{i}{j}(k) = mac_time{i}{j}(k)*process_power(op_mac{i}{j}(k))*price*c_rate;
            carbon_emission{i}{j}(k) = mac_time{i}{j}(k)*process_power(op_mac{i}{j}(k))*c_rate;

            %对应机器加工时间*加工功率*电费*碳转率
        end
    end
end


[pop_size,total_op_num] = size(pop);
for i = 1:pop_size
    pop_temp = pop(i,:);
    mac_car_total = zeros(1,mac_num);%把机器的碳排放量设为0
    for j = 1:total_op_num
        %找到j对应的工序是pop_temp(j)的第几个工序
        op_index = find(find(pop_temp(1:total_op_num) == pop_temp(j)) == j);
        machine = op_mac{pop_temp(j)}{op_index};%对应加工机器集合
        carbon = carbon_emission{pop_temp(j)}{op_index};%对应加工机器的碳排放量
        temp_carbon = zeros(1,mac_num);
        for k = 1:length(machine)
            temp_carbon(machine(k)) = mac_car_total(machine(k))+carbon(k);
        end
        index0 = find(temp_carbon ~= 0);%找总碳排放量不为零的机器的索引
        index1 = temp_carbon(index0);%对应总碳排放量
        index2 = find(index1 == min(index1));%找碳排放量最小的机器在index1中的位置
        mac_select = index0(index2(1));%选总碳排放量最小的第一个机器（可能有多个）
        pop_temp(total_op_num+j) = index2(1);%编码用的mac_select的在machine的序号
        mac_car_total(mac_select) = temp_carbon(mac_select);
    end
    pop_cs(i,:)=pop_temp;
end








