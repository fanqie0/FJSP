function pop_best = grid_divide(pop) %分割archive，得到网格
global total_op_num object_num
%pop = archive;
interval_num = 20;%方格数
[pop_num,pop_length] =size(pop);
[pop_sort,index] =sort(pop(:,total_op_num*2+1));%按照第一个目标函数值进行排序
pop_new = pop(index,:);%排好序的个体
max_value = max(pop_sort);%上边界
min_value = min(pop_sort);%下边界
interval = (max_value-min_value)/interval_num;%间隔
gx=linspace(min_value+interval,max_value-interval,interval_num-1);
grid_low = [min_value,gx];%方格下边界
grid_up = [gx,max_value];%上边界
for i = 1:interval_num
    temp = pop_sort>=grid_low(i) & pop_sort<grid_up(i);
    grid(i) = sum(temp);%每个网格中个体数量
end
grid(end) = grid(end)+1;%把最大那个放入最后一个格子
if min(grid)>0 %找非空格子
    grid_cumsum = cumsum(grid);%计算一下累计和吧
    less_grid = find(min(grid));%找到包含个体最少的格子，可能不止一个
    temp = randperm(length(less_grid),1);%随机选取一个格子
    position = grid_cumsum(less_grid(temp));%这是选中的最少个体的格子中的个体在grid_cumsum中的位置
    pop_best_position = index(position-grid(temp)+1:position);
    %position-grid(temp)+1是这个格子第一个个体在index中的位置，这个是在pop中的位置
    pop_best = pop(pop_best_position,:);
else
    grid = grid(find(grid>0));%找到非空格子
    grid_cumsum = cumsum(grid);%计算一下累计和吧
    less_grid = find(grid == min(grid));%找到包含个体最少的格子，可能不止一个
    temp = randperm(length(less_grid),1);%随机选取一个格子
    position = grid_cumsum(less_grid(temp));
    pop_best_position = index(position-grid(temp)+1:position);%这个是在pop中的位置
    pop_best = pop(pop_best_position,:);
end

