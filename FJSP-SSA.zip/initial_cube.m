function pop = initial_cube(pop_size,total_op_num,job_num) %这个初始化用立方混沌映射
for i = 1:pop_size
    y(1) = unifrnd(-1,1,1);
    for j = 1:total_op_num
        x(j) = -job_num + (job_num-(-job_num))*(y(j)+1)/2;
        y(j+1) = 4*y(j)^3-3*y(j);
        pop(i,j) = x(j); % 立方混沌映射后的种群
    end
end

for i = 1:pop_size
    for j = 1:total_op_num
        pop_bl(i,j) = rand*(-job_num+job_num)-pop(i,j);%反向学习后的种群
    end
end
pop_new = [pop;pop_bl];%合并后的种群



