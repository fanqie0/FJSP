function producer = update_producer_sincos_new(pop_best,pop_worst,ST,producer,max_iter) %i是迭代次数，ST是安全阈值，
global total_op_num;
object_num = 2;
producer_fit = producer(:,total_op_num+1+1:total_op_num+1+object_num);%个体目标函数值
producer = producer(:,1:total_op_num*2);
fit_best = pop_best(total_op_num*2+1);%这儿以时间为目标函数值
fit_worst = pop_worst(total_op_num*2+1);
w_min = 1;
w_max = 3;
for i = 1:size(producer,1)
    a(i) = sin(((producer_fit(i)-fit_best)/(fit_worst-fit_best+0.0001)+1)*pi/2+pi)+1;
    w(i) = w_min + (w_max-w_min)*a(i); %动态权重系数
end

if rand<ST  %安全
    for j = 1:size(producer,1)
        producer_new(j,:) = producer(j,:)*exp(-j/(rand*max_iter));
        producer_new(j,:) = bound(producer_new(j,:));
    end
else
    for j = 1:size(producer,1)
        producer_new(j,:) = producer(j,:) + w(j)*normrnd(0,1,1,total_op_num*2);
        producer_new(j,:) = bound(producer_new(j,:));
    end
end
%检查是否超出边界
producer_new_decode = position_scheduling(producer_new);
[Fit1,~,Fit2] = fitness(producer_new_decode);%求producer_new的适应度值
producer_new_fit = [Fit1',Fit2'];

for k = 1:size(producer,1)
    if  producer_fit(k,:)<= producer_new_fit(k,:) %老解支配新解
        producer_new(k,:) = producer(k,:);%保留老解
    end
end

producer = producer_new;