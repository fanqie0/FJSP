function pop_ideal = ideal_point(pop)%这个pop是要带目标函数值的
global total_op_num
total_op_num = 21;
object_num = 2;%目标函数
fit = pop(:,total_op_num+1:total_op_num+1+object_num);
for i = 1:size(fit,2)-1
    fit_mean(i) = mean(fit(:,i+1));%计算第i个目标函数值的平均值
    fit_std(i) = std(fit(:,i+1));%标准差
end
%第一步，归一化
for i = 1:size(fit,1)
    for j = 1:object_num
        fit(i,j+1) = (fit(i,j+1)-fit_mean(j))/fit_std(j);
    end
end
%第二步，求得理想点儿ip
for i = 1:object_num
   ip(i) = min(fit(:,i+1));
end
%第三步，计算每个点儿和理想点儿之间的距离
for i = 1:size(fit,1)
    for j = 1:object_num
        d_ij(i,j) = (ip(j)-fit(i,j+1))^2;
    end
    distance(i) = sum(d_ij(i,:))^0.5;
end
compromise_solution = fit(find(distance == min(distance)),1);%得到最接近理想点儿的个体的位置
index0 =randperm(length(compromise_solution),1);
index1 = find(pop(:,total_op_num+1) == compromise_solution(index0));
pop_ideal = pop(index1,:);%最接近理想点儿的个体


