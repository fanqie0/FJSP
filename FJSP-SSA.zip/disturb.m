function pop_new = disturb(i,pop)
global total_op_num
pop_fit = pop(total_op_num*2+1:end);
pop = pop(1:total_op_num*2);
pop_disturb = pop + trnd(i)*pop; %扰动
pop_disturb = bound(pop_disturb);

pop_disturb_decode = position_scheduling(pop_disturb); %解码
[Fit1,~,Fit2] = fitness(pop_disturb_decode); %计算适应度值
if Fit1<pop_fit(1) && Fit2<pop_fit(2)%新解支配老解
    pop_new = pop_disturb;
else
    pop_new = pop;
end