function pop_new = disturb_global(i,pop)
pop_decode = position_scheduling(pop);
[fit1,~,fit2] = fitness(pop_decode);

for j = 1:size(pop,1)
    pop_disturb(j,:) = pop(j,:) + trnd(i)*pop(j,:); %扰动
    pop_disturb(j,:) = bound(pop_disturb(j,:));
end

pop_disturb_decode = position_scheduling(pop_disturb); %解码
[Fit1,~,Fit2] = fitness(pop_disturb_decode); %计算适应度值
for k = 1:size(pop,1)
    if fit1(k)>Fit1(k) && fit2(k)>Fit2(k)%新解支配老解
        pop_new(k,:) = pop_disturb(k,:);
    else
        pop_new(k,:) = pop(k,:);
    end
end