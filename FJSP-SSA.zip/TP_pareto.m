function TP = TP_pareto()
pop = xlsread('C:\Users\ygd13\OneDrive\桌面\MK01-MK10.xlsx','mk02');
pop = pop(:,end-1:end);
%非支配排序
ns_record(1:length(pop)) = 0;%
pf1 = [];%记录个体pareto front的个体
%先找pareto front=1的个体
for i = 1:length(pop)
    for j = 1:length(pop)
        n_equal = 0;%相等的个数
        n_less = 0;
        n_more = 0;
        for k = 1:size(pop,2)
            if pop(i,k)<pop(j,k)
                n_more = n_more +1;
            elseif pop(i,k) == pop(j,k)
                n_equal = n_equal +1;
            else
                n_less = n_less +1;
            end
        end
        if n_more == 0 && n_equal ~= size(pop,2) % 说明i受j支配，相应的n加1
            ns_record(i) = ns_record(i) + 1; %被支配个体数
        end
    end
    if ns_record(i) == 0
        pf1 = [pf1,i];
    end
end
TP = pop(pf1,:);
end


