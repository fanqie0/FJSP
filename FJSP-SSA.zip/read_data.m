%idle_power和process_power是假设的机器空载和负载功率
idle_power = [3.45,2.82,0.84,1.58,1.41,0.55,1.02,1.80,1.23,1.60,0.64,3.00,1.65,1.34,3.20];
process_power = [20,15,6,12,10,5.5,7.5,10,12,14,9.5,16,13,11,18];
data = textread('TextData\Monaldo\Fjsp\Job_Data\Brandimarte_Data\Text\Mk02.fjs');
job_num = data(1,1);
mac_num = data(1,2);
op_num = data(2:end,1)';
op_mac = cell(1,job_num);
mac_time = cell(1,job_num);
total_op_num = sum(op_num);
job_rank= [];
for b = 1:job_num
    jobrank = ones(1,op_num(b))*b;
    job_rank = [job_rank,jobrank];
end
for i = 1:size(data,1)-1 %工件号
    data_set = data(i+1,:);
    a = 2;
    for j = 1:data_set(1) %工序号
        op_mac{i}{j} = [];
        mac_time{i}{j} = [];
        for k = 1:data_set(a) %第i个工件的第j个工序可加工机器数
            % op_mac_num = data_set(a); 
            mac_number = data_set(a+1);  % 机器号
            op_mac_time = data_set(a+2);  % 加工时间
            op_mac{i}{j} = [op_mac{i}{j},mac_number]; %把对应机器号放进op_mac
            mac_time{i}{j} = [mac_time{i}{j},op_mac_time]; %把对应机器加工时间放进mac_time
            a = a+2;
        end
        a = a+1;
    end
end
idle_power = idle_power(1:mac_num);
process_power = process_power(1:mac_num);

