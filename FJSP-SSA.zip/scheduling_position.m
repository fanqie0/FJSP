function pop = scheduling_position(pop,pop_new)
%pop是个体工序位置实数编码，pop_new则是调度解（工序排序+机器分配）
global mac_num 
global total_op_num op_mac
%run preset.m
%pop = [3	8	4	6	2	9	5	5	6	2	10	7	1	4	8	3	9	7	2	8	2	7	1	6	4	7	1	3	10	9	2	1	2	1	2	2	3	2	2	3	1	3	1	2	1	2	1	2	1	4	1	1	4	2	1	2	3	1	1	2];

for i = 1:size(pop_new,1)
    %pop_temp = pop_new(i,:);
    for j = 1:total_op_num
        ni = pop_new(i,total_op_num+j);%pop_temp(j)选择的机器序号
        temp_index = find(pop_new(i,1:total_op_num) == pop_new(i,j));
        op_index = find(temp_index == j); %j是第j个工件的第op_index个工序
        mac_number = size(op_mac{pop_new(i,j)}{op_index},2); %可选加工机器数
        if mac_number ~= 1
           pop_temp(i,j) = 2*mac_num*(ni-1)/(mac_number-1)-mac_num; %调度解转化为个体位置
        else
           pop_temp(i,j) = unifrnd(-mac_num,mac_num,1);
        end
    end
end
pop = [pop,pop_temp];
