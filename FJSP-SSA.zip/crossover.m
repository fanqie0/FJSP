function [pop_new,Fit] = crossover(pop,Pc)
global job_num total_op_num
%pop = pop_new;
[pop_size,pop_length] = size(pop);
pop_new = position_scheduling(pop);
offspring = [];%子代存放位置
for i = 1:2:pop_size
    if rand<Pc
        pop1_decode = pop_new(i,:);%解码后的pop1
        pop2_decode = pop_new(i+1,:);%调度解
        pop1 = pop(i,:);%个体位置
        pop2 = pop(i+1,:);
        pop1_index = sort_index(pop1(1:total_op_num));%这个则是个体位置的排名
        pop2_index = sort_index(pop2(1:total_op_num));
        offspring1 = zeros(1,pop_length);
        %offspring2 = zeros(1,pop_length);
        job_set = randperm(job_num);%这个就是要交换的工序号
        temp_num = randperm(job_num-1,1);%随机选择一个数字
        index_pop1 = [];%
        index_pop2 = [];
        for j = 1:temp_num
            index1 = find(pop1_decode(1:total_op_num) == job_set(j));%找job_set(j)的索引，准备保留到offspring1
            index_pop1 = [index_pop1,index1];
            index2 = find(pop2_decode(1:total_op_num) == job_set(j));%找job_set(j)的索引，把pop2中的位置赋值为0
            index_pop2 = [index_pop2,index2];
            offspring1(index1) = pop1(index1);%保留工序位置
            offspring1(total_op_num+index1) = pop1(total_op_num+index1);%保留机器位置
        end
        index_pop1 = sort(index_pop1);
        index_pop2 = sort(index_pop2);
        index_pop_total = (1:total_op_num);%pop2的全索引
        D_pop2_index = setdiff(index_pop_total,index_pop2,'stable');%找差集
        %找到pop2中复制到offspring2中的位置,同时也是把这个位置的工序复制到offspring1中的位置
        offspring2(D_pop2_index) = pop2(D_pop2_index);%把job_set中的另外一部分工件工序的位置复制到offspring2
        offspring2(total_op_num+D_pop2_index) = pop2(total_op_num+D_pop2_index);%把机器也复制过来

        D_pop1_index = setdiff(index_pop_total,index_pop1,'stable');%找到offspring1中空的位置
        temp_pop2 = pop2_index(D_pop2_index);%找pop2中要放到offspring1中的工件工序对应实数在个体位置中的排名
        for k = 1:length(temp_pop2)
            index_temp_pop2(k) = find(temp_pop2(k) == pop1_index);
        end
        offspring1(D_pop1_index) = pop1(index_temp_pop2);
        offspring1(total_op_num+D_pop1_index) = pop1(total_op_num+index_temp_pop2);
        index_temp_pop2 = [];%清空，防止影响下一次迭代
        temp_pop1 = pop1_index(index_pop1);
        for k = 1:length(temp_pop1)
            index_temp_pop1(k) = find(temp_pop1(k) == pop2_index);
        end
        offspring2(index_pop2) = pop2(index_temp_pop1);
        offspring2(total_op_num+index_pop2) = pop2(total_op_num+index_temp_pop1);
        index_temp_pop1 = [];
        offspring = [offspring;offspring1;offspring2];
    end
end
pop = [pop;offspring];
pop_decode = position_scheduling(pop);%解码
[fit,~] = fitness(pop_decode);
[Fit,index] = sort(fit);
pop_new = pop(index(1:pop_size),:);

