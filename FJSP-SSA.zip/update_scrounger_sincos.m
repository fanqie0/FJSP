function  scrounger = update_scrounger_sincos(pop_best,pop_worst,scrounger,pop_size,Prod_rate)
global total_op_num;
fit_best = pop_best(total_op_num*2+1);
fit_worst = pop_worst(total_op_num*2+1);
pop_best = pop_best(1:total_op_num*2);
pop_worst = pop_worst(1:total_op_num*2);
object_num = 2;%目标函数个数
scrounger_fit = scrounger(:,total_op_num+1+1:total_op_num+1+object_num);%个体目标函数值
scrounger = scrounger(:,1:total_op_num*2);

A = randi([0,1],1,total_op_num*2);
a = find(A == 0);
A(a) = -1;
%A = A'*inv(A*A');
for i = 1:size(scrounger,1)
    if i >  pop_size/2-pop_size*Prod_rate
        for j = 1:size(scrounger,2)
            scrounger_new(i,j) = normrnd(0,1,1)*exp((pop_worst(j)-scrounger(i,j))/(i^2));
        end
        scrounger_new(i,:) = bound(scrounger_new(i,:));
    else
        scrounger_new(i,:) = pop_best + sum(A.*(scrounger(i,:) - pop_best))/total_op_num/2;
        scrounger_new(i,:) = bound(scrounger_new(i,:));
    end
end
%保留较好个体
scrounger_new_decode = position_scheduling(scrounger_new);
[Fit1,~,Fit2] = fitness(scrounger_new_decode);%计算新个体的目标函数值
scrounger_new_fit = [Fit1',Fit2'];

for k = 1:size(scrounger,1)
    if scrounger_fit(k,:) < scrounger_new_fit(k,:)
        scrounger_new(k,:) = scrounger(k,:);
    end
end
scrounger = scrounger_new;
