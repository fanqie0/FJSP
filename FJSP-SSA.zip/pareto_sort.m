%非支配排序
function [pf,pop_new] = pareto_sort(pop,fit,make_co_sum,pop_size)
[pop_num,pop_length] = size(pop);
index(1:pop_num,1) = 1:pop_num;%标记pop序号，以便对应pval;
pop = [pop,index];%把序号放pop最后边，便于下边计算
object_num = 2; %目标函数个数
object = [pop,fit',make_co_sum'];%综合矩阵
ns_record(1:pop_num) = 0;%
pf1 = [];%记录个体pareto front的个体
 %data = cell(1,2);%记录数据
%先找pareto front=1的个体
for i = 1:pop_num
    sp = [];%被p支配的个体集合
    ns = 0;%支配p的个体数
    for j = 1:pop_num
        n_equal = 0;%相等的个数
        n_less = 0;
        n_more = 0;
        for k = 1:object_num
            if object(i,pop_length+1+k)<object(j,pop_length+1+k)
                n_more = n_more +1;
            elseif object(i,pop_length+1+k) == object(j,pop_length+1+k)
                n_equal = n_equal +1;
            else
                n_less = n_less +1;
            end
        end
        if n_more == 0 && n_equal ~= object_num % 说明i受j支配，相应的n加1
            ns_record(i) = ns_record(i) + 1; %被支配个体数
        elseif n_less == 0 && n_equal ~= object_num % 说明i支配j,把j加入i的支配合集中
            sp = [sp,j ];%支配个体集合
        end
    end
    data{i,1} = ns_record(i);
    data{i,2} = sp;
    if ns_record(i) == 0
        object(i,pop_length+1+object_num+1) = 1;
        pf1 = [pf1,i];
    end
end

%寻找剩下的pareto front
%data{i,1} = ns_record(i);
%data{i,2} = sp;
front = 1;
pf = {};%记录每一层的个体
while ~isempty(pf1)
    pf{front} = pf1;%记录每一层的个体
    Q = [];%找到下一层的个体
    for i = 1:length(pf1) %当前层的个体数
        if ~isempty(data{pf1(i),2}) 
            for j = 1:length(data{pf1(i),2}) %pf1中第i个个体支配个体的集合
                data{data{pf1(i),2}(j),1} = data{data{pf1(i),2}(j),1}-1;
                %把剩下个体集合中的pf1中的个体去除，那么每个个体被支配的个体数减1（其实是减去pf1的总数）
                if data{data{pf1(i),2}(j),1} == 0%该个体只被pf1中的个体支配
                    object(data{pf1(i),2}(j),pop_length+1+object_num+1)...
                        = front +1;%该个体是下一层的个体
                    Q = [Q,data{pf1(i),2}(j)];%统计下一层个体
                end
            end
        end
    end
    front = front + 1;
    pf1 =Q;
end


[temp,index_of_fronts] = sort(object(:,pop_length+1+object_num+1));
for i = 1 : length(index_of_fronts)
    sorted_based_on_front(i,:) = object(index_of_fronts(i),:); %把每一层的个体找出来排序
end
current_index = 0;

%% 拥挤度计算
%for front = 1:(length(pf)-1)
for front = 1:(length(pf))
%    objective = [];
    distance = 0;
    y = [];
    previous_index = current_index + 1;
    for i = 1 : length(pf{front})%第front层的个体数
        y(i,:) = sorted_based_on_front(current_index + i,:);%sorted_based_on_front是排好序的个体
    end
    current_index = current_index + i;
    % Sort each individual based on the objective
    sorted_based_on_objective = [];
    for i = 1 : object_num %
        [sorted_based_on_objective, index_of_objectives] = ...
            sort(y(:,pop_length+1 + i));
        sorted_based_on_objective = [];
        for j = 1 : length(index_of_objectives)
            sorted_based_on_objective(j,:) = y(index_of_objectives(j),:);
        end
        f_max = ...%第i个目标函数值最大的个体
            sorted_based_on_objective(length(index_of_objectives), pop_length+1 + i);
        f_min = sorted_based_on_objective(1, pop_length+1 + i);
        y(index_of_objectives(length(index_of_objectives)),pop_length+1 + object_num + 1 + i)...
            = Inf;%上边界设为inf,第一个1是pop序号，第2个1是pareto层数
        y(index_of_objectives(1),pop_length+1 + object_num+ 1 + i) = Inf;%下边界设为inf
         for j = 2 : length(index_of_objectives) - 1
            next_obj  = sorted_based_on_objective(j + 1,pop_length+1 + i);
            previous_obj  = sorted_based_on_objective(j - 1,pop_length+1 + i);
            if (f_max - f_min == 0)
                y(index_of_objectives(j),pop_length+1+object_num + 1 + i) = Inf;
            else
                y(index_of_objectives(j),pop_length+1+object_num + 1 + i) = ...
                     (next_obj - previous_obj)/(f_max - f_min);
            end
         end
    end
    distance = [];
    distance(:,1) = zeros(length(pf{front}),1);
    for i = 1 : object_num
        distance(:,1) = distance(:,1) + y(:,pop_length+1+object_num + 1 + i);
    end
    y(:,pop_length+1+object_num + 2) = distance;
    y = y(:,1 : pop_length+1+object_num + 2);
    z(previous_index:current_index,:) = y;%z就是最后输出结果
end
pop_new = z;



