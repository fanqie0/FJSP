function archive = archive_remove(archive,new_num)
global total_op_num
object_num = 2;
number = size(archive,1);%输入的个体数
archive_fit = archive(:,total_op_num*2+1:total_op_num*2+object_num);
[~,index]= unique(archive_fit,'row','first');%适应度值相同，保留第一个个体
archive = archive(index,:);%去除适应度相同值后的archive
a = sum(find(index>number-new_num));%找到有几个新个体被保留下来了
new_num = a;

max_archive = 80;
[pop_num,~] = size(archive);%输入archive的个体数
index(1:pop_num,1) = 1:pop_num;%标记pop序号
archive = [archive,index];%把编号放最后一列
object_num = 2; %目标函数个数
ns_record(1:pop_num) = 0;%
pf1 = [];%记录个体pareto front的个体

 %data = cell(1,2);%记录数据
%先找pareto front=1的个体
for i = 1:pop_num
    sp = [];%被p支配的个体集合
    ns = 0;%支配p的个体数
    for j = 1:pop_num
        n_equal = 0;%相等的个数
        n_less = 0;
        n_more = 0;
        for k = 1:object_num
            if archive(i,total_op_num*2+k)<archive(j,total_op_num*2+k)
                n_more = n_more +1;
            elseif archive(i,total_op_num*2+k) == archive(j,total_op_num*2+k)
                n_equal = n_equal +1;
            else
                n_less = n_less +1;
            end
        end
        if n_more == 0 && n_equal ~= object_num % 说明i受j支配，相应的n加1
            ns_record(i) = ns_record(i) + 1; %被支配个体数
        elseif n_less == 0 && n_equal ~= object_num % 说明i支配j,把j加入i的支配合集中
            sp = [sp,j ];%支配个体集合
        end
    end
    data{i,1} = ns_record(i);
    data{i,2} = sp;
    if ns_record(i) == 0
        archive(i,total_op_num*2+object_num+1+1) = 1;
        pf1 = [pf1,i];
    end
end

if length(pf1)>max_archive %pf1中的个体数超过了archive_max
    old_archive_index = find(pf1<=pop_num-new_num);
    old_archive = archive(old_archive_index,:);%这时archive顺序没有变
    new_archive_index = find(pf1>pop_num-new_num);
    new_archive = archive(new_archive_index,1:total_op_num*2+object_num);
    for j = 1 : object_num %
        [~,index] = sort(old_archive(:,total_op_num*2+j));%按第j个目标函数值进行排序
        old_archive = old_archive(index,:);
        f_max = old_archive(end,total_op_num*2+j);%第j个目标函数值最大的个体的值
        f_min = old_archive(1, total_op_num*2+j); 
        old_archive(end,total_op_num*2+object_num+1+j)=Inf;%把第j个目标函数值最大的个体拥挤都设为Inf
        old_archive(1,total_op_num*2+object_num+1+j)=Inf;
         for k = 2 : size(old_archive,1) - 1
             next_obj = old_archive(k+1,total_op_num*2+object_num+1+j);
             previous_obj = old_archive(k-1,total_op_num*2+object_num+1+j);
            if (f_max - f_min == 0)
                old_archive(k,total_op_num*2+object_num+1+j) = Inf;
            else
                old_archive(k,total_op_num*2+object_num+1+j) = ...
                     (next_obj - previous_obj)/(f_max - f_min);%算了每个目标函数下个体的拥挤度
            end
         end
    end
    old_archive(:,total_op_num*2+object_num+1+1)...%求总的拥挤度
        = sum(old_archive(:,total_op_num*2+object_num+1+1:total_op_num*2+object_num+1+object_num),2);%按行求和
    old_archive(:,total_op_num*2+object_num+1+1+1:end) = [];%把多于的数据给删除
    [~,index] = sort(old_archive(:,end));%对老个体的拥挤度进行排序
    old_archive = old_archive(index,:);%按照拥挤度对老个体进行排序
    remove_num = length(pf1)-max_archive;%删去老个体中remove_num个个体
    old_archive = old_archive(1:end-remove_num,:);%去除remove_num个个体之后的非支配解
    old_archive(:,total_op_num*2+object_num+1:end) =[]; %把序号给删了
    archive = [old_archive;new_archive];
else 
    archive(:,total_op_num*2+object_num+1:end) =[]; 
    archive = archive(pf1,:);
    
end


