function IGD_value = IGD(P,TP)
%TP是所有非支配解，P是某次运行得到的非支配解
num_TP =length(TP);%TP的个数
%x = TP(randperm(TP,1),:);%从TP中随机选择一个解
%TP = setdiff(TP,x,'rows');%去除解x
for i = 1:size(TP,1)
    for j = 1:size(P,1)
        d(i,j) = distance(P(j,:),TP(i,:));
    end
    min_d(i) = min(d(i,:));
end
IGD_value = 1/num_TP*sum(min_d);
end



function dis = distance(P,TP)
dis = ((P(1)-TP(1))^2+(P(2)-TP(2))^2)^(1/2);
end

