function pop_new = mutation(pop,pop_size,Pm)
%输入的pop是个体位置
% 变邻域则是对工序编码进行交叉互换
global total_op_num job_num mac_num op_mac

pop_decode = position_scheduling(pop);
pop_new = [];
pop_new_decode = [];
%% 工序变异（交换位置）
for i = 1:size(pop,1)
    if rand<Pm
        pop1 = pop(i,:);%原个体
        pop2 = pop(i,:);%交换过的个体
        pop1_decode = pop_decode(i,:);
        index = sort(randperm(total_op_num,2));%选取两个点儿
        %找index(1)对应工件的工序
        op_index1_pop1 = find(find(pop1_decode(1:total_op_num) == pop1_decode(index(1))) == index(1));
        %找index(2)对应工件的工序
        op_index2_pop1 = find(find(pop1_decode(1:total_op_num) == pop1_decode(index(2))) == index(2));
        %交换工序
        pop2(index(1)) = pop1(index(2));
        pop2(index(2)) = pop1(index(1));
        pop2_decode = position_scheduling(pop2);%解码
        %交换后个体pop2在index(2)位置上的工件工序
        op_index1_pop2 = find(pop2_decode(1:total_op_num) == pop2_decode(index(2)));
        op_index1_pop2 = find(op_index1_pop2 == index(2));

        %交换后个体pop2在index(1)位置上的工件工序
        op_index2_pop2 = find(pop2_decode(1:total_op_num) == pop2_decode(index(1)));
        op_index2_pop2 = find(op_index2_pop2 == index(1));

        %找原个体中op_index1_pop2和op_index2_pop2的位置
        %找到pop1中index(1)对应工件的所有工序在pop1中的位置
        op_index3_pop1 = find(pop1_decode(1:total_op_num) == pop1_decode(index(1)));
        %找到原个体pop1中index(1)对应工件的第op_index1_pop2个工序所在位置
        op_index3_pop1 = op_index3_pop1(op_index1_pop2);
        %找到pop1中index(2)对应工件的所有工序在pop1中的位置
        op_index4_pop1 = find(pop1_decode(1:total_op_num) == pop1_decode(index(2)));
        %找到原个体pop1中index(1)对应工件的第op_index2_pop2个工序所在位置
        op_index4_pop1 = op_index4_pop1(op_index2_pop2);

        %找交换后个体pop2中op_index1_pop1和op_index2_pop1的位置
        %找到pop2中index(2)对应工件的所有工序在pop2中的位置
        op_index3_pop2 = find(pop2_decode(1:total_op_num) == pop2_decode(index(2)));
        %找到原个体pop1中index(2)对应工件的第op_index1_pop2个工序所在位置
        op_index3_pop2 = op_index3_pop2(op_index1_pop1);
        %找到pop2中index(1)对应工件的所有工序在pop2中的位置
        op_index4_pop2 = find(pop2_decode(1:total_op_num) == pop2_decode(index(1)));
        %找到原个体pop1中index(1)对应工件的第op_index1_pop2个工序所在位置
        op_index4_pop2 = op_index4_pop2(op_index2_pop1);
        pop2(total_op_num+index(2)) = pop1(total_op_num+op_index3_pop1);
        pop2(total_op_num+index(1)) = pop1(total_op_num+op_index4_pop1);
        pop2(total_op_num+op_index3_pop2) = pop1(total_op_num+index(1));
        pop2(total_op_num+op_index4_pop2) = pop1(total_op_num + index(2));
        pop_new = [pop_new;pop2];
        pop_new_decode = [pop_new_decode;pop2_decode];
    end
end
%% 机器变异,随机选中两个变异点儿，然后更换机器
for i = 1:size(pop_new,1)
    if rand<Pm
        index_mac = randperm(total_op_num,2);
        for j = 1:length(index_mac)
            op_index = find(find(pop_new_decode(i,1:total_op_num) == pop_new_decode(i,index_mac(j))) == index_mac(j));
            tol_mac =1: length(op_mac{pop_new_decode(i,index_mac(j))}{op_index});
            mac_tol = length(tol_mac);
            if length(tol_mac) ~= 1 %判断可加工机器数是否大于1台
                tol_mac = setdiff(tol_mac,pop_new_decode(i,total_op_num+index_mac(j)));
                temp_index = randperm(length(tol_mac),1);
                mac_sel = tol_mac(temp_index);%这里也是序号，不是编号
                mac_pos = 2*mac_num*(mac_sel-1)/(mac_tol-1)-mac_num;%调度解转换为个体位置公式
                pop_new(i,total_op_num+index_mac(j)) = mac_pos;
            end
        end
    end
end


pop_new = [pop;pop_new];
%pop_new_decode = [pop_decode;pop_new_decode];
pop_new = unique(pop_new,'rows','stable');
pop_new_decode = position_scheduling(pop_new);
[fit,~] = fitness(pop_new_decode);
[Fit,index] = sort(fit);
if size(pop_new,1)< pop_size
    lack_num = pop_size-size(pop_new,1);%缺少的个体
    for j = 1:lack_num
        lack_pop(j,1:total_op_num) = unifrnd(-job_num,job_num);
        lack_pop(j,total_op_num+1:total_op_num*2) = unifrnd(-mac_num,mac_num);
    end
    pop_new = [pop_new(index,:);lack_pop];%可能除去重复值之后，个体数少于pop_size了
else
    pop_new = pop_new(index(1:pop_size),:);
end

%}