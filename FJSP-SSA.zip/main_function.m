clc
clear
tic
%% 定义全局变量
global job_num job_rank 
global mac_num mac_time idle_power process_power 
global total_op_num op_mac 
%run ceshuju.m;
%run preset_new.m;
%% 数据预处理
%run preset.m %初始化数据
run read_data.m;
archive_history = [];
for kk = 1:10
%% 算法参数
object_num = 2;
pop_size = 200; %种群大小
code_length = total_op_num; %编码长度
max_iter = 500; %迭代次数
ST = 0.5;  %安全阈值ST
Prod_rate = 0.7;  %发现者比例
SD_rate = 0.2;  %警惕者比例
Pc = 0.7;%交叉概率
Pm = 0.2;%变异概率
fit_best_history = [inf,inf];%记录数据
i_history = [];
archive = [];%外部非支配个体
min_Fit1 = inf;%存放第一个目标函数的最小值
min_Fit2 = inf;
%% 
% 初始化种群
pop = initial_cube(pop_size,total_op_num,job_num);
decode_pop = decode_op(pop,job_rank); %先解码成工序编码
pop_new = decode_mac(decode_pop,op_mac,mac_time,mac_num,process_power);%这个是解码成调度解
pop_new = scheduling_position(pop,pop_new);%直接转化成个体位置

for i = 1:max_iter
%计算适应度值
pop_new_decode = position_scheduling(pop_new);%转换为调度解
[Fit1,~,Fit2] = fitness(pop_new_decode);%算适应度值
%[Fit1,~,Fit2] = fitness_test(pop_new_decode);%算适应度值
[pf,pop_new] = pareto_sort(pop_new,Fit1,Fit2,pop_size); %非支配排序

temp_pop = [pop_new(1:length(pf{1}),1:total_op_num*2),pop_new(1:length(pf{1}),total_op_num*2+1+1:total_op_num*2+1+object_num)];
archive = [archive;temp_pop];
archive = archive_remove(archive,length(pf{1}));%把新的非支配解放入archive
%pval1 = pval1(pop(:,total_op_num+1),:);%把每个个体对应的调度解中工件的加工时间对应好
%% 找最优解集和最差解
pop_best = grid_divide(archive);%从archive中选择最优解集
pop_best = pop_best(randperm(size(pop_best,1),1),:);%随机选择一个最优解
pop_worst = [pop_new(end,1:total_op_num*2),pop_new(end,total_op_num*2+1+1:total_op_num*2+1+object_num)];
    %把最后一个个体当作最差解
%% 画图
temp_Fit1 = min(Fit1);%找第一个目标函数的最小值
temp_Fit2 = min(Fit2);
if temp_Fit1 < min_Fit1(end)%对第一个目标函数，是否保留上一代目标值
    min_Fit1(i) = temp_Fit1;
else 
    min_Fit1(i) = min_Fit1(end);
end

if temp_Fit2 < min_Fit2(end)%对第二个目标函数，是否保留上一代目标值
    min_Fit2(i) = temp_Fit2;
else 
    min_Fit2(i) = min_Fit2(end);
end

i_history = [i_history,i];
%fprintf('迭代次数'),disp(i)

%% 选择发现者、加入者和警惕者

producer = pop_new(1:pop_size*Prod_rate,:);  %发现者
scrounger = pop_new(pop_size*Prod_rate+1:end,:); %加入者
id_list = randperm(pop_size); %产生随机数
guarder = pop_new(id_list(1:pop_size*SD_rate),:); %警惕者
%% 更新位置

producer = update_producer_sincos(pop_best,pop_worst,ST,producer,max_iter);
scrounger = update_scrounger_sincos(pop_best,pop_worst,scrounger,pop_size,Prod_rate);
guarder = update_guarder_sincos(pop_best,pop_worst,guarder);
%}
%{
producer = update_producer_sincos_new(pop_best,pop_worst,ST,producer,max_iter);
scrounger = update_scrounger_sincos_new(pop_best,pop_worst,scrounger,pop_size,Prod_rate);
guarder = update_guarder_sincos_new(pop_best,pop_worst,guarder);
%}
%把警惕者放入种群
pop_new = [producer;scrounger];
pop_new(id_list(1:pop_size*SD_rate),:) = guarder;%把警惕者放入种群
%}
%% 进行交叉变异
pop_new = pop_new(:,1:total_op_num*2);
pop_new = crossover(pop_new,Pc);
pop_new = mutation(pop_new,pop_size,Pm);
%}
%% 扰动
if i>20 && (min_Fit1(i) == min_Fit1(i-5) || min_Fit2(i) == min_Fit2(i-5))
    pop_new = disturb_global(i,pop_new);
end 
%}
end
disp(kk)
archive_value = archive(:,end-1:end);
if size(archive_value,1) == 1
    FITNESS(kk,:) = archive_value;
else
    FITNESS(kk,:) = min(archive_value);
end
archive_history = [archive_history ; archive];


archive_history = unique(archive_history,'row');
value = archive_history(:,end-1:end);
value = unique(value,'rows');
%IGD和HV是求反世代距离和超几何体积的
%{
TP = TP_pareto();
P = archive(:,end-1:end);
IGD_value(kk,:) = IGD(P,TP);%计算IGD
HV_value(kk,:) = HV(P);
%}
end
toc
%}

%% 画图
fit_best_history = [min_Fit1',min_Fit2'];% 记录最佳适应度值
figure(1)
plot(i_history,fit_best_history(:,1))
figure(2)
plot(i_history,fit_best_history(:,2))

figure(3)
decode_pop_best = position_scheduling(archive(1,1:total_op_num*2));
[FITNESS,pval,~] = fitness(decode_pop_best);
for i=1:total_op_num
    a=decode_pop_best(total_op_num+i); %可选机器集合序号
    b=decode_pop_best(i);%工件号
    c = find(decode_pop_best(1:total_op_num) == b);%i对应的工件的工序号
    d = find(c == i);
    m_text = op_mac{b}{d}(a); %机器号
    x1=pval(i);  %开始时间
    x2=pval(total_op_num+i); %结束时间
    y1=m_text-0.2; % 矩形的高
    y2=m_text;
    hold on;
    fill([x1,x2,x2,x1],[y1,y1,y2,y2],'r');
   % text((x1+x2)/2,mText-0.1,num2str(b));
end
%}

 




