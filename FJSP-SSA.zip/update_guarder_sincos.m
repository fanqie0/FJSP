function guarder = update_guarder_sincos(pop_best,pop_worst,guarder)
global total_op_num;
object_num = 2;
guarder_fit = guarder(:,total_op_num*2+1+1);%个体加工时间的目标函数值
guarder_fit1 = guarder(:,total_op_num*2+1+1:total_op_num*2+1+object_num);%个体的两个目标函数值
guarder = guarder(:,1:total_op_num*2);
fit_worst = pop_worst(:,total_op_num*2+1);%适应度最差的目标函数值
pop_worst = pop_worst(:,1:total_op_num*2);
fit_best = pop_best(total_op_num*2+1);
pop_best = pop_best(1:total_op_num*2);

for i = 1:size(guarder,1)
    if isequal(guarder_fit(i,:), fit_best)%如果
        guarder_new(i,:) = guarder(i,:) + unifrnd(-1,1)*(guarder(i,:) - pop_worst)/((guarder_fit(i)-fit_worst)+unifrnd(0.00001,0.00005));
        guarder_new(i,:) = bound(guarder_new(i,:));
    else
        guarder_new(i,:) = pop_best + normrnd(0,1)*(guarder(i,:) - pop_best);
        guarder_new(i,:) = bound(guarder_new(i,:));
    end
end
guarder_new_decode = position_scheduling(guarder_new);
[Fit1,~,Fit2] = fitness(guarder_new_decode);
guarder_new_fit = [Fit1',Fit2'];

for k = 1:size(guarder,1)
    if guarder_fit1(k,:) <= guarder_new_fit(k,:)
       guarder_new(k,:) = guarder(k,:);
    end
end
guarder = guarder_new;