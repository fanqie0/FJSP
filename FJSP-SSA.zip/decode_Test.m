%function pop_new = decode(pop)
%global job_num job_rank; 
%global total_op_num op_mac;
run ceshuju.m
pop = [0.974245978931812	-2.81999230749102	5.96824531372024	5.71622098588822	3.60451072246308	-5.61002142021062	-2.78776945322968	5.95602033356190	5.60804197240405	2.77294917119372	-5.94974847027530	-5.55277256540379	-2.36503884261014	5.62526887204387	2.90241990425609	-5.99058136330155	-5.91540959831139	-5.25293020251044	-0.346270656480603	1.03419874524268	-2.97969124733450	301	169	605.300000000000	11	Inf];
pop = pop(1:total_op_num);
%生成随机数
%pop = unifrnd(-8,8,5,size(data,1));
%job_rank = data(:,1)'; %对工件工序进行排序
for i = 1 : size(pop,1)
    [~,index] = sort(pop(i,:)); %对实数编码进行排序
    pop_new(i,1:total_op_num) = job_rank(index); %生成工序编码

    pop_new(i,total_op_num+1:total_op_num*2) = 0; %给机器编码赋值空间

    for j = 1:total_op_num
        op_index = find(find(pop_new(i,:) == pop_new(i,j)) == j);
        mac_number = size(op_mac{pop_new(i,j)}{op_index},2);
        pop_new(i,total_op_num+j) = round(1/(job_num*2)*(pop(i,j)+job_num)*(mac_number-1)+1);
    end
    %for j = 1:size(data,1)
       % j_index = find(pop_sort == pop(i,j)); %找到j对应的索引
        %job_number = pop_new(i,j_index);% 找到索引对应的工件号
        %op_site = find(pop_new(i,:) == pop_new(i,j_index)); %找到工件所有工序的位置
        %op_number = find(op_site == j_index); %找到i对应的是第几个工序
        %mac_number  = size(op_mac{job_number}{op_number},2);
        %pop_new(i,size(data,1)+j) = round(1/(job_num*2)*(pop(i,j)+job_num)*(mac_number-1)+1);
    %end
end

