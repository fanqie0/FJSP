%全局搜索
function pop_gl = global_search(pop,op_mac,mac_time,mac_num)
[pop_size,total_op_num] = size(pop);
for i = 1:pop_size
    pop_temp = pop(i,:);
    mac_time_total = zeros(1,mac_num);%把机器的总时间设为0
    for j = 1:total_op_num
        %找到j对应的工序是pop_temp(j)的第几个工序
        op_index = find(find(pop_temp(1:total_op_num) == pop_temp(j)) == j);
        machine = op_mac{pop_temp(j)}{op_index};%对应加工机器集合
        time = mac_time{pop_temp(j)}{op_index};%对应加工机器加工时间
        temp_time = zeros(1,mac_num);
        for k = 1:length(machine)
            temp_time(machine(k)) = mac_time_total(machine(k))+time(k);
        end
        index0 = find(temp_time ~= 0);%找总加工时间不为零的机器的索引
        index1 = temp_time(index0);%对应总加工时间
        index2 = find(index1 == min(index1));%找加工总时间最小的机器在index1中的位置
        mac_select = index0(index2(1));%选总加工时间最短的第一个机器（可能有多个）
        pop_temp(total_op_num+j) = index2(1);%编码用的mac_select的在machine的序号
        mac_time_total(mac_select) = temp_time(mac_select);
    end
    pop_gl(i,:)=pop_temp;
end
        


